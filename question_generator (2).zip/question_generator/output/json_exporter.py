import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from question_generator.schemas import Question


GENERATOR_VERSION = "1.0.0"

DIFFICULTIES = ("Easy", "Medium", "Hard")


def _validate_questions(
    questions: list[Question],
) -> None:
    if not isinstance(questions, list):
        raise TypeError("questions must be a list")

    if any(
        not isinstance(question, Question)
        for question in questions
    ):
        raise TypeError(
            "questions must contain only Question objects"
        )


def _build_metadata(
    *,
    source_file: str,
) -> dict[str, Any]:
    if not isinstance(source_file, str) or not source_file.strip():
        raise ValueError(
            "source_file must be a non-empty string"
        )

    return {
        "source_file": source_file,
        "generated_at": datetime.now(
            timezone.utc
        ).isoformat(),
        "generator_version": GENERATOR_VERSION,
    }


def questions_to_dict(
    questions: list[Question],
    *,
    source_file: str,
) -> dict[str, Any]:
    """Convert questions into the legacy flat JSON structure."""

    _validate_questions(questions)

    return {
        "metadata": _build_metadata(
            source_file=source_file,
        ),
        "questions": [
            question.to_dict()
            for question in questions
        ],
    }


def questions_to_topic_dict(
    questions: list[Question],
    *,
    source_file: str,
) -> dict[str, Any]:
    """Convert questions into a chapter/topic-oriented JSON structure."""

    _validate_questions(questions)

    metadata = _build_metadata(
        source_file=source_file,
    )

    if not questions:
        return {
            "metadata": metadata,
            "chapter": "",
            "topics": [],
        }

    chapters = {
        question.chapter
        for question in questions
    }

    if len(chapters) != 1:
        raise ValueError(
            "questions must belong to exactly one chapter"
        )

    chapter = next(iter(chapters))

    topics: dict[str, dict[str, list[dict[str, Any]]]] = (
        defaultdict(
            lambda: {
                difficulty: []
                for difficulty in DIFFICULTIES
            }
        )
    )

    for question in questions:
        if question.chapter != chapter:
            raise ValueError(
                "questions must belong to exactly one chapter"
            )

        if question.difficulty not in DIFFICULTIES:
            raise ValueError(
                f"invalid difficulty: {question.difficulty!r}"
            )

        topics[question.topic][
            question.difficulty
        ].append(question.to_dict())

    topic_list = [
        {
            "topic": topic,
            "questions": {
                difficulty: difficulties[difficulty]
                for difficulty in DIFFICULTIES
            },
        }
        for topic, difficulties in topics.items()
    ]

    return {
        "metadata": metadata,
        "chapter": chapter,
        "topics": topic_list,
    }


def export_questions_json(
    questions: list[Question],
    output_path: str | Path,
    *,
    source_file: str,
) -> Path:
    """Export questions to the legacy flat JSON structure."""

    data = questions_to_dict(
        questions,
        source_file=source_file,
    )

    output = Path(output_path)

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with output.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=2,
        )

    return output


def export_topic_questions_json(
    questions: list[Question],
    output_path: str | Path,
    *,
    source_file: str,
) -> Path:
    """Export questions to chapter/topic-oriented JSON."""

    data = questions_to_topic_dict(
        questions,
        source_file=source_file,
    )

    output = Path(output_path)

    output.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with output.open(
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=2,
        )

    return output